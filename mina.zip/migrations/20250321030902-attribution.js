"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("attribution", {
      attribution_id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
      },
      contribuable_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      price: {
        type: Sequelize.FLOAT,
        allowNull: false,
      },
      attribution_date: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.NOW
      },
      user_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      subrecipe_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "subrecipe",
          key: "subRecipe_id",
        },
        onUpdate: "CASCADE",
        onDelete: "SET NULL",
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("attribution");
  },
};
