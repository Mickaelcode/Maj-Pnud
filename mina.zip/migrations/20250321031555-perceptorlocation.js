"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("perceptorlocation", {
      perceptorLocation_id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
      },
      perceptor_id: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      localizationId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "localizations",
          key: "localization_id",
        },
        onUpdate: "CASCADE",
        onDelete: "CASCADE",
      },
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("perceptorlocation");
  },
};
