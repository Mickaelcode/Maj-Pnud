"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("ticket", {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        unique: true,
        primaryKey: true,
        autoIncrement: true
      },
      matriculeCollector: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      matriculeCashier: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      dateGrant: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.NOW,
      },
      dateSale: {
        type: Sequelize.DATE,
        allowNull: true,
      },
      isSolde: {
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: false,
      },
      subRecipe_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "subrecipe",
          key: "subRecipe_id",
        },
        onUpdate: "CASCADE",
        onDelete: "CASCADE",
      },
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("ticket");
  },
};
